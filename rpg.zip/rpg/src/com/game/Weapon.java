package com.game;

public enum Weapon {
	woodenSword, steelSword, wand, staff, shank, dagger
}
